#include<cstdio>
#include "ResultPackage.h"
#include "ListByArray.h"
#include "ListByLink.h"
bool SolByArray(int InitN, int InitM)//由顺序存储构成的线性表进行约瑟夫问题的求解
{
	ListByArray List;//构建顺序存储线性表
	ResultList resultList;//构建结果线性表
	FILE* fout = fopen("AnsByArray.out", "w");//结果将输出至AnsByArray.out中
	if(!List.InitList(InitN)) return false;//传入N，初始化线性表
	if(!resultList.InitList(InitN)) return false;//传入N,初始化结果线性表
	for (int i = 1; i <= InitN; i++) 
		if(!List.Insert(i)) //插入初始的n个数字
			return false;
	int NowPos = 0;//当前位置（数组下标从0开始计算）
	ResultPackage Result;//当前的结果包，用于对结果线性表进行插入操作
	int PreCost = 0;//记录前置代价
	while(!List.IsEmpty())//当线性表不为空
	{
		if(!List.MoveByMovement(&NowPos, InitM - 1)) 
		//传入数组当前位置，将其挪动至后M-1位
		//此处有两种情况：
		//1:未删除任何元素，此时初始下标为0，只需跳m-1步即可达到需要删除元素
		//2:删除了某一元素，此时下标停留至上一次删除的元素位置，仍只需跳m-1步即可到达目标元素
			return false;
		if(!List.DeleteElement(NowPos, &Result)) 
			return false;
		Result.Cost += PreCost;//结果包的代价加上前置代价
		PreCost = Result.Cost;
		if(!resultList.Insert(Result)) //结果线性表中插入结果包
			return false;
	}
	resultList.PrintList(fout);	//结果线性表输出至文件中
	if(!List.DestroyList()) return false;//摧毁线性表
	if(!resultList.DestroyList()) return false;//摧毁结果线性表
	fclose(fout);
	#ifdef TEST
	//此处为测试模块，若在g++编译时添加-DTEST编译参数即可启用，会在AnsForChecker.out临时输出以供检测输出是否正确。
	{
		FILE* fdebug = fopen("AnsForChecker.out", "w");
		fprintf(fdebug, "%d\n", Result.Pos);
		fclose(fdebug);
	}
	#endif
	return true;
}
bool SolByLink(int InitN, int InitM)//由链式存储构成的线性表进行约瑟夫问题的求解
{
	ListByLink List;//构建链式存储线性表
	ResultList resultList;//构建结果线性表
	FILE* fout = fopen("AnsByLink.out", "w");//结果将输出至AnsByLink.out中
	if(!List.InitList()) return false;//初始化线性表
	if(!resultList.InitList(InitN)) return false;//传入N,初始化结果线性表
	for(int i = 1; i <= InitN; i++)
		if(!List.AddToTail(i)) //插入初始的n个数字
			return false;
	ResultPackage Result;//当前的结果包，用于对结果线性表进行插入操作
	int PreCost = 0;//记录前置代价
	while(!List.IsEmpty())//当线性表不为空
	{
		if(!List.DeleteNextMthElement(InitM, &Result)) //删除线性表的当前位置起数的第m个元素
			return false;
		Result.Cost += PreCost;//结果包的代价加上前置代价
		PreCost = Result.Cost;
		if(!resultList.Insert(Result)) 
			return false;//结果线性表中插入结果包
	}
	resultList.PrintList(fout);	//结果线性表输出至文件中
	if(!List.DestroyList()) return false;//摧毁线性表
	if(!resultList.DestroyList()) return false;//摧毁结果线性表
	fclose(fout);
	return true;
}
int main()
{
	
	int InitN, InitM;//输入的n,m
	#ifdef TEST
	//此处为测试模块，若在g++编译时添加-DTEST编译参数即可启用，若启用则会在test.in文件中读入n,m否则会在命令行中读入n,m。
	{
		FILE* fin = fopen("test.in", "r");
		fscanf(fin, "%d%d", &InitN, &InitM);
		fclose(fin);
	}
	#else 
		printf("Joseph Problem Solving\nPlease type in N,M (divided by space,such as 15 3)\n");
		scanf("%d%d", &InitN, &InitM);
	#endif
	bool PassTest = 1;//是否通过测试，为1表示通过测试
	if(InitN <= 0 || InitM <= 0) //测试输入是否合法，若不合法则输出ERROR!
	{
		FILE* fout = fopen("AnsByLink.out", "w");
		fprintf(fout, "ERROR!\n");
		fclose(fout);
		fout = fopen("AnsByArray.out", "w");
		fprintf(fout, "ERROR!\n");
		fclose(fout);
		PassTest = 0;
	}
	if(PassTest)//若输入合法
	{
		if(!SolByArray(InitN, InitM)) PassTest = 0;
		if(!SolByLink(InitN, InitM)) PassTest = 0;
	}
	#ifdef TEST
	//测试模块启用时在测试输出流中输出ERROR!
	{
		if(PassTest == 0)
			{
				FILE* fdebug = fopen("AnsForChecker.out", "w");
				fprintf(fdebug, "ERROR!\n");
				fclose(fdebug);
			}
	}
	#endif
}