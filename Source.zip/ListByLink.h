struct ListNode
{
	int Data;
	ListNode *Next;
};
bool ListNodeInit(ListNode **x);
struct ListByLink
{
	ListNode *Tail, *Cur;
	int ListLength;
	bool InitList();
	bool DestroyList();
	bool AddToTail(int x);
	bool DeleteNextElement(ResultPackage *Result);
	bool DeleteNextMthElement(int m, ResultPackage *Result);
	bool PrintListForDebug();
	int GetSize();
	bool IsEmpty();
};
